import 'package:flutter/material.dart';

class AppColors {
  static const Color background = Color(0xFF020B1A);
  static const Color primary = Color(0xFF3399FF);
  static const Color secondary = Color(0xFF67E8F9);
  static const Color accent = Color(0xFFA78BFA);
  static const Color surface = Color(0xFF0E1A30);
  static const Color glass = Color(0x1AFFFFFF);
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFFA3ADC2);

  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFF3399FF), Color(0xFF67E8F9)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class AppTheme {
  static ThemeData get creativeTheme {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.background,
      primaryColor: AppColors.primary,
      fontFamily: 'Cairo',
      textTheme: const TextTheme(
        displayLarge: TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.bold, fontSize: 32),
        displayMedium: TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.bold, fontSize: 24),
        bodyLarge: TextStyle(color: AppColors.textPrimary, fontSize: 16),
        bodyMedium: TextStyle(color: AppColors.textSecondary, fontSize: 14),
      ),
    );
  }
}
