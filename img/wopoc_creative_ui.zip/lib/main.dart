import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'theme.dart';
import 'screens/home_screen.dart';
import 'screens/wallet_screen.dart';

void main() {
  runApp(const WopocApp());
}

class WopocApp extends StatelessWidget {
  const WopocApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'WOPOC AI Creative',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.creativeTheme,
      // تفعيل دعم اللغة العربية وتنسيق اليمين لليسار
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('ar', 'SA'),
      ],
      locale: const Locale('ar', 'SA'),
      // نقطة البداية هي واجهة الهبوط، ويمكن الانتقال للمحفظة
      home: const MainNavigation(),
    );
  }
}

class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _currentIndex = 0;
  final List<Widget> _screens = [
    const HomeScreen(),
    const WalletScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: _currentIndex == 0 ? null : null, // Bottom nav is inside screens for custom design
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            _currentIndex = _currentIndex == 0 ? 1 : 0;
          });
        },
        backgroundColor: AppColors.primary,
        child: Icon(_currentIndex == 0 ? Icons.wallet_rounded : Icons.home_rounded),
      ),
    );
  }
}
